from django.apps import AppConfig

class GestionAcademicaConfig(AppConfig):
      name='GestionAcademica'

# Create your tests here.


